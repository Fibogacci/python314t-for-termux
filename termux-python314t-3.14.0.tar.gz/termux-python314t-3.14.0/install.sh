#!/data/data/com.termux/files/usr/bin/bash
# Termux installation script dla Python 3.14t

set -e

echo "=== Python 3.14t (free-threading) Installation ==="
echo ""

# Detect PREFIX (default: $HOME/.local)
PREFIX="${PREFIX:-$HOME/.local}"
echo "Installation prefix: $PREFIX"

# Create directories
mkdir -p "$PREFIX"/{bin,lib,include}

# Copy files
echo "Copying files..."
cp -v bin/* "$PREFIX/bin/"
cp -v lib/libpython3.14t.so "$PREFIX/lib/"
cp -rv lib/python3.14t "$PREFIX/lib/"

if [ -d "include/python3.14t" ]; then
    cp -rv include/python3.14t "$PREFIX/include/"
fi

# Fix permissions
chmod +x "$PREFIX/bin/python3.14t"

# Check if PATH includes $PREFIX/bin
if [[ ":$PATH:" != *":$PREFIX/bin:"* ]]; then
    echo ""
    echo "⚠️  Add to your ~/.bashrc:"
    echo 'export PATH="$HOME/.local/bin:$PATH"'
    echo 'export LD_LIBRARY_PATH="$HOME/.local/lib:$LD_LIBRARY_PATH"'
    echo ""
    echo "Then run: source ~/.bashrc"
fi

echo ""
echo "✅ Installation complete!"
echo ""
echo "Test with:"
echo "  $PREFIX/bin/python3.14t --version"
echo "  $PREFIX/bin/python3.14t -c 'import sys; print(f\"GIL: {sys._is_gil_enabled()}\")'"
