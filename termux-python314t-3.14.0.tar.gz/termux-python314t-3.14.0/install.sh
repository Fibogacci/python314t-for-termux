#!/data/data/com.termux/files/usr/bin/bash
# Termux installation script dla Python 3.14t

set -e

echo "=== Python 3.14t (free-threading) Installation ==="
echo ""

# Detect PREFIX (default: $HOME/.local)
# Force $HOME/.local for Termux to avoid conflicts with system Python
if [ -z "$PREFIX" ] || [ "$PREFIX" = "/data/data/com.termux/files/usr" ]; then
    PREFIX="$HOME/.local"
fi
echo "Installation prefix: $PREFIX"

# Create directories
mkdir -p "$PREFIX"/{bin,lib,include}

# Copy files (only python3.14t binary, not symlinks)
echo "Copying files..."
cp -v bin/python3.14t "$PREFIX/bin/"
cp -v lib/libpython3.14t.so "$PREFIX/lib/"
cp -rv lib/python3.14t "$PREFIX/lib/"

if [ -d "include/python3.14t" ]; then
    cp -rv include/python3.14t "$PREFIX/include/"
fi

# Fix permissions
chmod +x "$PREFIX/bin/python3.14t"

# Configure shell environment
BASHRC="$HOME/.bashrc"
NEED_CONFIG=false

# Check if PATH includes $PREFIX/bin
if [[ ":$PATH:" != *":$PREFIX/bin:"* ]]; then
    NEED_CONFIG=true
fi

# Check if LD_LIBRARY_PATH includes $PREFIX/lib
if [[ ":$LD_LIBRARY_PATH:" != *":$PREFIX/lib:"* ]]; then
    NEED_CONFIG=true
fi

if [ "$NEED_CONFIG" = true ]; then
    echo ""
    echo "⚠️  Shell configuration needed!"
    echo ""
    read -p "Add PATH and LD_LIBRARY_PATH to ~/.bashrc? [Y/n] " -n 1 -r
    echo ""

    if [[ $REPLY =~ ^[Yy]$ ]] || [[ -z $REPLY ]]; then
        # Add configuration to .bashrc
        echo "" >> "$BASHRC"
        echo "# Python 3.14t free-threading" >> "$BASHRC"
        echo "export PATH=\"$PREFIX/bin:\$PATH\"" >> "$BASHRC"
        echo "export LD_LIBRARY_PATH=\"$PREFIX/lib:\$LD_LIBRARY_PATH\"" >> "$BASHRC"

        echo "✅ Configuration added to ~/.bashrc"
        echo "Run: source ~/.bashrc"
    else
        echo ""
        echo "Manually add to your ~/.bashrc:"
        echo "  export PATH=\"$PREFIX/bin:\$PATH\""
        echo "  export LD_LIBRARY_PATH=\"$PREFIX/lib:\$LD_LIBRARY_PATH\""
        echo ""
        echo "Then run: source ~/.bashrc"
    fi
fi

echo ""
echo "✅ Installation complete!"
echo ""
echo "Test with:"
echo "  $PREFIX/bin/python3.14t --version"
echo "  $PREFIX/bin/python3.14t -c 'import sys; print(f\"GIL: {sys._is_gil_enabled()}\")'"\
