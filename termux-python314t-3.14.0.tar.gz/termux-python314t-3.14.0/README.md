# Python 3.14.0 Free-Threading dla Termux

**Built:** czw, 23 paź 2025, 23:45:45 CEST
**Architecture:** aarch64-linux-android (ARM64)
**GIL:** Disabled (free-threading enabled)

## Installation

```bash
# Run installation script (installs to ~/.local by default)
bash install.sh

# The script will prompt to configure your ~/.bashrc automatically
# If you choose 'Y', it will add PATH and LD_LIBRARY_PATH

# Or manual installation to custom prefix:
PREFIX=/path/to/install bash install.sh
```

**Important:** The installer will NOT overwrite system Python (`python` or `python3` symlinks).
Only `python3.14t` binary will be installed to avoid conflicts.

## Verify

After installation and sourcing ~/.bashrc:
```bash
source ~/.bashrc

python3.14t --version
python3.14t -c "import sys; print(f'GIL enabled: {sys._is_gil_enabled()}')"
```

Expected output:
```
Python 3.14.0
GIL enabled: False
```

## Integration z uv

```bash
# Install uv (if not already)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Initialize project with Python 3.14t
uv init my-project --python 3.14t
cd my-project
uv run python --version
```

## Size

- Binary: ~7KB (python3.14t)
- Shared lib: ~31MB (libpython3.14t.so)
- Stdlib: ~34MB (python3.14t/ - cleaned)
- Total: ~94MB

## Contents

- `bin/python3.14t` - Interpreter
- `lib/libpython3.14t.so` - Shared library
- `lib/python3.14t/` - Standard library (cleaned)
- `include/python3.14t/` - Headers

## Removed modules (size optimization)

- `test/` - 152MB test suite
- `idlelib/` - IDLE IDE
- `tkinter/` - Tk/Tcl GUI
- `turtledemo/` - Turtle graphics
- `ensurepip/` - pip installer
- `pydoc_data/` - Documentation data
- `__pycache__/` - Bytecode cache (will regenerate)

Install pip separately:
```bash
wget https://bootstrap.pypa.io/get-pip.py
python3.14t get-pip.py
```
